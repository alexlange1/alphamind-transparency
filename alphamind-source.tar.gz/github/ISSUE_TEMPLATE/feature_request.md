---
name: Feature request
description: Suggest an idea
labels: enhancement
---

## Problem / Motivation

## Proposal

## Alternatives considered

## Impact / Risks

## Additional context
