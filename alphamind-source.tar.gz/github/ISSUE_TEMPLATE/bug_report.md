---
name: Bug report
description: Report a bug
labels: bug
---

## Describe the bug

## To Reproduce
Steps to reproduce the behavior:

## Expected behavior

## Screenshots/logs

## Environment
- Commit:
- Python:
- OS:

## Additional context
