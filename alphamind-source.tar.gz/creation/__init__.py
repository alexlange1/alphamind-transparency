"""
TAO20 Creation Unit System

This module implements the ETF-style creation/redemption system for TAO20.
"""

__version__ = "1.0.0"
__author__ = "Alphamind Team"
